HAPPY WORLD - PROYEK APLIKASI ANDROID
=====================================

Yang disertakan:
- Game HTML asli dari file yang diberikan.
- Pembungkus Android WebView agar game dapat dijalankan sebagai aplikasi.
- Ikon aplikasi pixel art.
- Pengaturan layar penuh dan penyimpanan localStorage WebView.

PENTING:
Folder ini adalah proyek sumber Android Studio, bukan file APK yang sudah dikompilasi.
Lingkungan pembuatan file ini tidak memiliki Android SDK/Gradle, jadi APK belum dapat
dibangun dan diuji di sini.

CARA MEMBUAT APK:
1. Ekstrak ZIP ini.
2. Buka Android Studio.
3. Pilih Open, lalu pilih folder HappyWorld (folder yang berisi settings.gradle).
4. Tunggu Gradle Sync selesai. Jika diminta, pasang Android SDK Platform 35 dan JDK 17.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Setelah selesai, tekan "locate" pada notifikasi Android Studio untuk menemukan APK.
   Biasanya hasilnya ada di app/build/outputs/apk/debug/app-debug.apk.

Untuk memasang di HP:
- Pindahkan app-debug.apk ke HP Android.
- Buka file APK dan izinkan instalasi dari sumber yang diminta Android.

Catatan:
- Game memakai Google Fonts melalui internet. Jika tidak ada internet, font akan
  menggunakan font monospace cadangan; game tetap bisa dijalankan.
- Progres game menggunakan penyimpanan lokal WebView (localStorage).
- ID aplikasi: com.happyworld.lifesim
